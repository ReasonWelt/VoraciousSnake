package demo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;

/*
  贪吃蛇游戏，吃满10个就算游戏结束。
*/

public class MyPanel extends JPanel implements KeyListener, ActionListener {
    //声明右侧蛇头和图片
    ImageIcon right = new ImageIcon("src/photo/right.jpg");
    ImageIcon body = new ImageIcon("src/photo/wei.jpg");
    //声明蛇头上下左侧的图片
    ImageIcon top = new ImageIcon("src/photo/top.jpg");
    ImageIcon bottom = new ImageIcon("src/photo/bottom.jpg");
    ImageIcon left = new ImageIcon("src/photo/left.jpg");

    //声明一个初始值。表示蛇的长度为3
    int length = 3;

    //创建随机数对象
    Random random = new Random();

    //声明两个数组存放x和y的坐标位置[最大值 = 宽度格子*高度格子]
    int [] snakeMaxX = new int[1008];
    int [] snakeMaxy = new int[1008];

    //声明枚举类型的变量。控制蛇头方向
    Direction direction = Direction.right;

    //声明一个变量。标记游戏是否开始，当为true表示开始游戏
    Boolean isStart = false;

    //声明一个变量，标记游戏是否结束
    Boolean Over = true;

    //创建一个定时器对象
    Timer timer = new Timer(100,this);

    //声明两个变量表示food的坐标位置
    int foodx;
    int foody;
    //声明一个food图片
    ImageIcon food = new ImageIcon("src/photo/food.jpg");

    public MyPanel(){
        //设定蛇的头部和身体的初始位置
        //头部
        snakeMaxX[0] = 100;
        snakeMaxy[0] = 100;
        //身体
        snakeMaxX[1] = 75;
        snakeMaxy[1] = 100;
        snakeMaxX[2] = 50;
        snakeMaxy[2] = 100;

        //获取键盘事件
        this.setFocusable(true);
        //添加监听
        this.addKeyListener(this);

        //启动定时器
        timer.start();


        //生成food的坐标
        foodx = 25 + 25 * random.nextInt(26);
        foody = 25 + 25 * random.nextInt(34);

    }

    //重写画组件的方法
    @Override
    protected void paintComponent(Graphics g) {
        //调用父类的方法，做一些基本工作
        super.paintComponent(g);
        //设置背景颜色
        this.setBackground(Color.CYAN);
        //在画布中添加游戏区域
        g.fillRect(0,0,700,900);

        //添加右侧蛇头
        //right.paintIcon(this,g,snakeMaxX[0],snakeMaxy[0]);
        //根据枚举的类型判断添加哪个头
        switch(direction){
            case top:
                top.paintIcon(this,g,snakeMaxX[0],snakeMaxy[0]);
                break;
            case left:
                left.paintIcon(this,g,snakeMaxX[0],snakeMaxy[0]);
                break;
            case right:
                right.paintIcon(this,g,snakeMaxX[0],snakeMaxy[0]);
                break;
            case bottom:
                bottom.paintIcon(this,g,snakeMaxX[0],snakeMaxy[0]);
                break;

        }
        //添加两个身体
        /*body.paintIcon(this,g,75,100);
        body.paintIcon(this,g,50,100);*/
        for (int i = 1 ; i<length ; i++){
            body.paintIcon(this,g,snakeMaxX[i],snakeMaxy[i]);
        }

        //标记游戏是否开始的值isStart
        if (!isStart && Over){
            //放上开始提示信息
            g.setColor(Color.WHITE);
            g.setFont(new Font("宋体",Font.BOLD,30));
            g.drawString("请按空格键表示游戏开始!",150,450);
        }else if (!Over){
            g.setColor(Color.WHITE);
            g.setFont(new Font("宋体",Font.BOLD,30));
            g.drawString("游戏结束",150,450);
        }


        food.paintIcon(this,g,foodx,foody);
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        int keycode = e.getKeyCode();
        //判断，当我们按空格键的时候，数字值是32
        //这个值是从keyCode得出的
        if (keycode == KeyEvent.VK_SPACE){
            //标记游戏状态的值取反
            isStart = !isStart;
            //重新画组件
            repaint();
        }else if (keycode == KeyEvent.VK_UP){
            direction = Direction.top;
        }else if (keycode == KeyEvent.VK_DOWN){
            direction = Direction.bottom;
        }else if (keycode == KeyEvent.VK_LEFT){
            direction = Direction.left;
        }else if (keycode == KeyEvent.VK_RIGHT){
            direction = Direction.right;
        }

    }

    @Override
    public void keyReleased(KeyEvent e) {

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (isStart && Over){
            //移动身体
            for (int i = length-1 ; i>0;i--){
                snakeMaxX[i] = snakeMaxX[i-1];
                snakeMaxy[i] = snakeMaxy[i-1];
            }
            //通过方向值direction，移动蛇头
            switch(direction){
                case top:
                    //水平向上
                    snakeMaxy[0] -=25;
                    if (snakeMaxy[0] <= 0){
                        snakeMaxy[0] = 900;
                    }
                    break;
                case right:
                    //假如蛇头是水平向右移动，则蛇头的值+25
                    snakeMaxX[0] +=25;
                    //判断当前蛇头是否超出700，超出则x值从零开始
                    if (snakeMaxX[0]>=700){
                        snakeMaxX[0] = 0;
                    }
                    break;
                case left:
                    //水平向左移动
                    snakeMaxX[0] -= 25;
                    if (snakeMaxX[0]<=0){
                        snakeMaxX[0]=700;
                    }
                    break;
                case bottom:
                    //水平向下
                    snakeMaxy[0] += 25;
                    if (snakeMaxy[0] >=900){
                        snakeMaxy[0] = 0;
                    }
                    break;

            }

            //当蛇头x，y和food的x，y一致的时候，就表示吃掉食物
            if (snakeMaxX[0] == foodx && snakeMaxy[0] == foody){
                //蛇的长度加一
                length++;

                //重新生成失物的坐标位置
                foodx = 25 + 25 * random.nextInt(26);
                foody = 25 + 25 * random.nextInt(34);
            }

            if (length>11){
                Over = false;
            }

            //重新画组件方法
            repaint();
            //从新启动定时器
            timer.start();
        }
    }
}
