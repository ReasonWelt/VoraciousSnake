package demo;

public enum Direction {
    //定义枚举四个方向
    top,bottom,left,right;
}
